using System;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Activation;

using Aspects.Properties;

namespace Aspects.Attributes {

	/// <summary>
	/// Context-attribute that is used to add a context-property, namely, Aspects.Properties.LogProperty into the 
	/// target context during the object activation phase of a context-bound object's lifecycle.
	/// </summary>
	[AttributeUsage (AttributeTargets.Class)]
	public class MiddlewareAttribute : Attribute, IContextAttribute {
		public MiddlewareAttribute() {}

		public void GetPropertiesForNewContext(IConstructionCallMessage msg) {
			MiddlewareProperty property = new MiddlewareProperty ();
			msg.ContextProperties.Add(property);
		}

		public bool IsContextOK(Context ctx, IConstructionCallMessage msg) {
			return false;
		}
	}
}
