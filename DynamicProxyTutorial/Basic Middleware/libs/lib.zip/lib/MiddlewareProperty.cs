using System;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Messaging;

using Aspects.Sinks;

namespace Aspects.Properties {
	/// <summary>
	/// Context-property which is added to the target context by CLR during the 
	/// object activation phase of a context-bound object's lifecycle.
	/// This property also functions as a factory for server context sinks, namely, Aspects.Sinks.ModifiedLoggingServerSink or Aspects.Sinks.LoggingServerSink
	/// </summary>
	public class MiddlewareProperty : IContextProperty, IContributeServerContextSink
	{
		public MiddlewareProperty() {}

		public string Name 
		{
			get	{return "MiddlewareProperty";}
		}

		public bool IsNewContextOK(Context newCtx)
		{
			return true;
		}

		public void Freeze(Context newContext) {}

		public IMessageSink GetServerContextSink(IMessageSink nextSink) 
		{
			 return new TrucoDeMagiaServerSink (nextSink);
		}
	}
}
