using System;
using System.Collections;
using System.Runtime.Remoting.Messaging;

namespace Aspects.Attributes {

	/// <summary>
	/// Custom attribute used to annotate methods that we want to advise at runtime by injecting an aspect.
	/// </summary>
	[AttributeUsage (AttributeTargets.Method)]
	public class LogMethodAttribute : Attribute {
		public LogMethodAttribute() {}

		/// <summary>
		/// Method representing the advice injected by this attribute.
		/// </summary>
		/// <param name="methodMsg"></param>
		public void log (IMethodMessage methodMsg) {

			Console.WriteLine("Begin aspect injection");

			IDictionaryEnumerator propertyEnumerator = (IDictionaryEnumerator) methodMsg.Properties.GetEnumerator();

			while (propertyEnumerator.MoveNext()) {
				object pKey   = propertyEnumerator.Key;
				string pName  = pKey.ToString();
				object pValue = propertyEnumerator.Value;

				if (pName == "__Args") {
					object[] args = (object[]) pValue;
					for (int i = 0; i < args.Length; i++)
						Console.WriteLine("Arg [{0}] = {1}", i, args[i].ToString());
				}

				if ((pName == "__MethodSignature") && (null != pValue)) {
					object[] args = (object[])pValue;
					for (int i = 0; i < args.Length; i++)
						Console.WriteLine("Param [{0}] = {1}", i, args[i].ToString());
				}
			}

			Console.WriteLine("End aspect injection");

		}
	}
}
