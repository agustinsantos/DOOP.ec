using System;
using System.Collections;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Activation;

namespace Aspects.Sinks {

	/// <summary>
	/// Message sink that is used to intercept all method invocations on a context-bound object
	/// An instance of this sink is added as a server sink into the invocation chain by Aspects.Properties.LogProperty
	/// </summary>
	public class TrucoDeMagiaServerSink : IMessageSink {
		private IMessageSink next;
		public TrucoDeMagiaServerSink (IMessageSink next) {this.next = next;}

		public IMessage SyncProcessMessage(IMessage msg) 
		{			if (msg is IMethodMessage) 
			{
				IDictionaryEnumerator propertyEnumerator = (IDictionaryEnumerator) msg.Properties.GetEnumerator();
                IMethodMessage method = msg as IMethodMessage;
				
                while (propertyEnumerator.MoveNext()) 
				{
					object pKey   = propertyEnumerator.Key;
					string pName  = pKey.ToString();
					object pValue = propertyEnumerator.Value;

					if (pName == "__Args") {
						object[] args = (object[]) pValue;
						if (msg is IConstructionCallMessage && args.Length > 0)
				        {
							Console.WriteLine("Te he pillado!!. Esto es un constructor con parámetros!!!!");
						}
					}

					if ((pName == "__MethodSignature") && (null != pValue))
                    {		
						if (!(String.Equals("Saluda", method.MethodName) ||
						      String.Equals("get_Fortune", method.MethodName) || 
                              msg is IConstructionCallMessage))
                        {
						    Console.WriteLine("El método que has hecho se llama:" + method.MethodName);
							foreach (Type p in pValue as Type[])
							{
                               Console.WriteLine("Tiene un parámetro de tipo " + p);
                            }
					    }
				     }
			   }
			}

			IMessage replyMessage = next.SyncProcessMessage (msg);
			
            // aqui podría venir el codigo para despues de la llamada
			if (msg is IMethodMessage && String.Equals("get_Fortune", (msg as IMethodCallMessage).MethodName))
		    {
                IMethodReturnMessage rm = replyMessage as System.Runtime.Remoting.Messaging.IMethodReturnMessage;
				IDictionaryEnumerator repplyEnumerator = (IDictionaryEnumerator) replyMessage.Properties.GetEnumerator();
                while (repplyEnumerator.MoveNext()) 
				{
				   object pKey   = repplyEnumerator.Key;
				   string pName  = pKey.ToString();
				   object pValue = repplyEnumerator.Value;				
                   if ((pName == "__Return") && (null != pValue) && (pValue is System.String))
                   {
	                    ReturnMessage rm2 = new ReturnMessage("Otra Cosa",
						                                      rm.Args, rm .ArgCount,
						                                      rm.LogicalCallContext,
                                                              msg as IMethodCallMessage);     
                        return (IMessage) rm2; 
                   }
                }
            }


			return replyMessage;
		}

		public IMessageSink NextSink {get {return this.next;}}
		public IMessageCtrl AsyncProcessMessage(IMessage msg, IMessageSink replySink) {
			return null;
		}
	}
}


