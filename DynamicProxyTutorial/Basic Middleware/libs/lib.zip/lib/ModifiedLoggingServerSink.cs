using System;
using System.Collections;
using System.Runtime.Remoting.Messaging;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Activation;
using System.Reflection;

using Aspects.Attributes;

namespace Aspects.Sinks {

	/// <summary>
	/// Message sink that is used to intercept all method invocations on a context-bound object 
	/// only if the method has been annotated with the custom attribute, Aspects.Attributes.LogMethodAttribute
	/// An instance of this sink is added as a server sink into the invocation chain by Aspects.Properties.LogProperty
	/// </summary>
	public class ModifiedLoggingServerSink  : IMessageSink {
		private IMessageSink next;
		public ModifiedLoggingServerSink (IMessageSink next) {this.next = next;}

		public IMessage SyncProcessMessage(IMessage msg) {
			if (msg is IMethodMessage) {
				InjectAspect (msg as IMethodMessage);
			}
			return next.SyncProcessMessage (msg);
		}

		public IMessageSink NextSink {get {return this.next;}}
		public IMessageCtrl AsyncProcessMessage(IMessage msg, IMessageSink replySink) {
			return null;
		}

		private void InjectAspect (IMethodMessage methodMsg) {
			MethodBase methodInfo = methodMsg.MethodBase;
			object[] arrayOfCustomAttributes = methodInfo.GetCustomAttributes (true);
			foreach (Attribute attr in arrayOfCustomAttributes) {
				if (attr.GetType() == typeof(LogMethodAttribute)) {
					LogMethodAttribute logAttr = (LogMethodAttribute) attr;
					logAttr.log (methodMsg);
				}
			}
		}
	}
}
