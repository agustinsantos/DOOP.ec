﻿This is the first DDS DCPS test.
It shows that the DomainParticipant, Topic, Publisher, Subscriber,
DataReader and DataWriter can do the minimal work necessary.
