﻿This is the second DDS DCPS test.
A test for QoS implementation.
