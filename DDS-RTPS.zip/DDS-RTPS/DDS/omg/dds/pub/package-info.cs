/**
 * The Publication Module contains the {@link Publisher }and
 * {@link DataWriter} interfaces as well as the {@link PublisherListener }and
 * {@link DataWriterListener} interfaces, and more generally, all that is
 * needed on the publication side.
 */
namespace org.omg.dds.pub
{ }
